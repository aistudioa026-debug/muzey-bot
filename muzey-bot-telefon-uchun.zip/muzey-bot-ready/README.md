# 3D Muzey Telegram bot — telefon orqali joylashtirish

## Nima qiladi
- Telegram `/start` buyrug‘i va “Muzeyni ochish” tugmasi
- Rasm/video yuklab 3D muzey ko‘rish
- Muzeyni havola va QR-kod bilan ulashish
- Bitta web-service ichida veb-sahifa va Telegram botni ishga tushirish

## Render’da ishga tushirish
1. ZIP faylni oching va ichidagi fayllarni GitHub’dagi yangi repository’ga yuklang. `server.py`, `requirements.txt`, `render.yaml`, `static/index.html` repository ildizida turishi kerak.
2. Render’da New + → Web Service orqali GitHub repository’ni ulang.
3. Build command: `pip install -r requirements.txt`
4. Start command: `uvicorn server:app --host 0.0.0.0 --port $PORT`
5. Environment variables qo‘shing:
   - `BOT_TOKEN` = BotFather bergan token
   - `BASE_URL` = Render bergan HTTPS manzil, masalan `https://your-service.onrender.com` (o‘zingizning manzilingizni yozing)
   - `DATA_DIR` = `data`
6. Deploy qiling. `BASE_URL` ni o‘zgartirgandan keyin qayta deploy/restart qiling.
7. Brauzerda `https://YOUR-SERVICE.onrender.com/health` oching. `ok: true` va `bot_configured: true` bo‘lsa, server bot tokenini ko‘rmoqda.
8. Telegram’da botingizni ochib `/start` yuboring va “Muzeyni ochish” tugmasini bosing.

## Muhim
- `BOT_TOKEN` maxfiy: uni hech kimga va chatga yubormang; faqat hostingdagi Environment Variables maydoniga kiriting.
- Bepul hostingda server uxlab qolishi va `data` papkasidagi muzeylar qayta ishga tushganda yo‘qolishi mumkin. Muzeylarni doimiy saqlash uchun hostingning doimiy diskini yoki tashqi fayl saqlash xizmatini sozlash kerak.
- Har bir rasm/video 10 MB gacha, bitta muzeyda 30 tagacha fayl.
- `BASE_URL` HTTPS bo‘lishi shart; Telegram Mini App oddiy HTTP manzilida ishlamaydi.
