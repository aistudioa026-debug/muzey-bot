import io
import json
import os
import shutil
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

import qrcode
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, MenuButtonWebApp, Update, WebAppInfo
from telegram.ext import Application, CommandHandler, ContextTypes

BASE_URL = os.getenv("BASE_URL", "http://localhost:8000").rstrip("/")
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
DATA = Path(os.getenv("DATA_DIR", "data"))
DATA.mkdir(parents=True, exist_ok=True)
MAX_FILES = 30
MAX_BYTES = 10 * 1024 * 1024
ALLOWED = {
    "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp",
    "video/mp4": ".mp4", "video/webm": ".webm", "video/quicktime": ".mov",
}
bot_app = None

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = InlineKeyboardMarkup([[InlineKeyboardButton(
        "🖼 Muzeyni ochish", web_app=WebAppInfo(url=BASE_URL)
    )]])
    if update.message:
        await update.message.reply_text(
            "Rasm va videolaringizdan 3D muzey yarating. Tayyor muzeyni havola yoki QR-kod bilan ulashing.",
            reply_markup=keyboard,
        )

@asynccontextmanager
async def lifespan(app: FastAPI):
    global bot_app
    if BOT_TOKEN:
        bot_app = Application.builder().token(BOT_TOKEN).build()
        bot_app.add_handler(CommandHandler("start", start_command))
        await bot_app.initialize()
        await bot_app.start()
        if bot_app.updater:
            await bot_app.updater.start_polling()
        await bot_app.bot.set_chat_menu_button(
            menu_button=MenuButtonWebApp(text="Muzey", web_app=WebAppInfo(url=BASE_URL))
        )
        print("Telegram bot ishga tushdi")
    else:
        print("DIQQAT: BOT_TOKEN kiritilmagan; veb-sahifa ishlaydi, bot polling ishlamaydi")
    try:
        yield
    finally:
        if bot_app:
            if bot_app.updater and bot_app.updater.running:
                await bot_app.updater.stop()
            await bot_app.stop()
            await bot_app.shutdown()
            bot_app = None

app = FastAPI(title="3D Muzey", lifespan=lifespan)

@app.get("/health")
def health():
    return {"ok": True, "bot_configured": bool(BOT_TOKEN)}

@app.get("/")
def index():
    return FileResponse("static/index.html")

@app.post("/api/museums")
async def create_museum(files: list[UploadFile] = File(...)):
    if not files or len(files) > MAX_FILES:
        raise HTTPException(400, "1 dan 30 gacha fayl yuboring")
    mid = uuid.uuid4().hex[:10]
    folder = DATA / mid
    folder.mkdir(parents=True, exist_ok=False)
    items = []
    try:
        for i, f in enumerate(files):
            ext = ALLOWED.get(f.content_type)
            if not ext:
                continue
            blob = await f.read(MAX_BYTES + 1)
            if len(blob) > MAX_BYTES:
                continue
            name = f"{i}{ext}"
            (folder / name).write_bytes(blob)
            items.append({"url": f"/files/{mid}/{name}", "video": ext in (".mp4", ".webm", ".mov")})
        if not items:
            shutil.rmtree(folder, ignore_errors=True)
            raise HTTPException(400, "Mos fayl topilmadi. Har bir fayl 10 MB gacha bo‘lsin.")
        (folder / "meta.json").write_text(json.dumps(items), encoding="utf-8")
        return {"id": mid, "items": items}
    except Exception:
        if not (folder / "meta.json").exists():
            shutil.rmtree(folder, ignore_errors=True)
        raise

@app.get("/api/museums/{mid}")
def get_museum(mid: str):
    meta = DATA / mid / "meta.json"
    if not mid.isalnum() or not meta.exists():
        raise HTTPException(404, "Muzey topilmadi")
    return {"id": mid, "items": json.loads(meta.read_text(encoding="utf-8"))}

@app.get("/api/qr/{mid}.png")
def qr(mid: str):
    if not mid.isalnum() or not (DATA / mid / "meta.json").exists():
        raise HTTPException(404, "Muzey topilmadi")
    buf = io.BytesIO()
    qrcode.make(f"{BASE_URL}/?m={mid}").save(buf, format="PNG")
    return Response(buf.getvalue(), media_type="image/png")

app.mount("/files", StaticFiles(directory=str(DATA)), name="files")
